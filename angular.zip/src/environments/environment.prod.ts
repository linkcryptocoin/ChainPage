export const environment = {
  production: true,
  HttpProvider: ""
};
