import { Injectable } from '@angular/core';

@Injectable()
export class Globals {
  isLoggedIn: boolean = false;
  public Globals() {console.log("in Globals class: " + this.isLoggedIn);}
}