﻿import { Component, OnInit, Input } from '@angular/core';
import { UserService, ClaimService, AlertService } from '../_services/index';
import { Router, ActivatedRoute, Params, ParamMap } from '@angular/router';
import { Http, Response } from '@angular/http';
import { User, Claim } from '../_models/index';
import { forEach } from '@angular/router/src/utils/collection';
// import { HttpRequest } from '@angular/common/http';
import 'rxjs/add/operator/switchMap';
@Component({
    moduleId: module.id.toString(),
    templateUrl: 'home.component.html'
})

export class HomeComponent implements OnInit {
    @Input() catId = 0;
    currentUser: User;
    model: any = {};
    claims: any;
    submitted = false;
    categories: any[] = [];
    countries: any[] = [];
    catParam = "";
    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private userService: UserService,
        private claimService: ClaimService,
        private alertService: AlertService,
        private http: Http
    ) {
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if(this.currentUser) {
            this.model.submitBy = this.currentUser.username;
        }
        this.http.get('/assets/cat.json')
            .subscribe(data => {
                this.categories = data.json();
                //console.log(data);
            });
        this.http.get('/assets/country.json')
            .subscribe(data => {
                this.countries = data.json();
                //console.log(data);
            });
        //get query param
        this.route.queryParams.subscribe(params => {
            console.log(params['cat']);
            this.catParam = params['cat'];
            //console.log(this.catParam);
            if(!this.catParam){
                //console.log('loadAllClaims');
                this.loadAllClaims();
            }
            else{
                //console.log('loadClaimsByCat');
                this.loadClaimsByCat(parseInt(this.catParam));
            }
        });
        
    }

    public getCountryName(id: number): string {
        var value = "";
        this.countries.forEach(pair => {
          if(pair.ID == id)
          {
            value = pair.Country;
            //break;
          }
      });
      return value;
    }
    public getCategoryName(id: string): string {
        var value = "";
        this.categories.forEach(pair => {
          //console.log(pair.Country)
          if(pair.Category == id)
          {
            value = pair.Description;
            //break;
          }
      });
      return value;
    }
    deleteClaim(id: number) {
        this.claimService.delete(id).subscribe(() => { this.loadAllClaims() });
    }
    editClaim(id: number) {
        this.claimService.getById(id).subscribe(claim => { this.model = claim });;
        //console.log(this.model);
    }
    approveClaim(id: number) {
        alert("approved");
    }
    private loadAllClaims() {
        this.claimService.getAll().subscribe(claims => { this.claims = claims; });
    }
    private loadClaimsByCat(cat: number) {
        this.claimService.getByCat(cat).subscribe(claim => { this.claims = claim; });
    }
    isAuthor(user: string): boolean {
        //console.log(this.currentUser.username == user);
        return this.currentUser.username == user;
    }
    // test() {
    //     this.model = new Claim(2, "John", "John Business", "123 abc st.", "DC", "DC", 20001,
    //         1, "test@test.com", "123-123-1234", "http://test.com", "Baby", "DC", "9-5",
    //         "1001", "form1");
    // }
    ngOnInit() {
        //console.log("ngOnInit");
        // this.claims = this.route.paramMap
        //     .switchMap((params: ParamMap) =>
        //         this.claimService.getByCat(params.get('id')));
        // let urlParts = this.request.url.split('/');
        // let id = parseInt(urlParts[urlParts.length - 1]);
        // console.log(id);
        
        // this.route.params.forEach((params: Params) => {
        //     console.log(params['cat']);
        // });
    }
    // currentUser: User;
    // users: User[] = [];

    // constructor(private userService: UserService, private claimService: ClaimService) {
    //     this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
    // }

    // ngOnInit() {
    //     this.loadAllUsers();        
    // }

    // deleteUser(id: number) {
    //     this.userService.delete(id).subscribe(() => { this.loadAllUsers() });
    // }

    // private loadAllUsers() {
    //     this.userService.getAll().subscribe(users => { this.users = users; });
    // }

}