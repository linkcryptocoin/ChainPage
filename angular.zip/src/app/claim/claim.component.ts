import { Component, OnInit } from '@angular/core';
import { Claim, User } from '../_models/index'
import { UserService, ClaimService, AlertService } from '../_services/index';
import { Router } from '@angular/router';
import { Http, Response } from '@angular/http';
import { driver} from '../../../node_modules/bigchaindb-driver';



@Component({
  moduleId: module.id.toString(),
  selector: 'app-claim',
  templateUrl: './claim.component.html',
  styleUrls: ['./claim.component.css']
})
export class ClaimComponent implements OnInit {
  currentUser: User;
  model: any = {};
  claims: Claim[] = [];
  submitted = false;
  categories: any[] = [];
  countries: any[] = [];
  states: any[] = [];
  provinces: any[] = [];
  state_province: any[] = [];
  readonly driver = require('bigchaindb-driver');
// BigchainDB server instance or IPDB (e.g. https://test.ipdb.io/api/v1/)
readonly API_PATH = 'http://localhost:9984/api/v1/';
// Create a new keypair.
readonly alice = new driver.Ed25519Keypair();
 tx: any;
 txSigned: any;
 conn: any;
  constructor(
    private router: Router,
    private userService: UserService,
    private claimService: ClaimService,
    private alertService: AlertService,
    private http: Http
  ) {
    this.currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
    console.log(this.currentUser.username);
    this.model.submitBy = this.currentUser.username;
    this.http.get('/assets/cat.json')
      .subscribe(data => {
        this.categories = data.json();
        //console.log(data);
      });
    this.http.get('/assets/country.json')
      .subscribe(data => {
        this.countries = data.json();
        //console.log(data);
      });
      this.http.get('/assets/us_states.json')
      .subscribe(data => {
        this.states = data.json();
        this.state_province = this.states;
        //console.log(data);
      });
      this.http.get('/assets/canada_provinces.json')
      .subscribe(data => {
        this.provinces = data.json();
        //console.log(data);
      });
      
  }

  onSubmit() {
    this.submitted = true;
    console.log(JSON.stringify(this.model));
    this.tx = driver.Transaction.makeCreateTransaction(JSON.stringify(this.model), { FormType: this.model.businessCategory },
    [ driver.Transaction.makeOutput(
      driver.Transaction.makeEd25519Condition(this.alice.publicKey))
    ],
    this.alice.publicKey);
    this.txSigned = driver.Transaction.signTransaction(this.tx, this.alice.privateKey);
    this.conn = new driver.Connection(this.API_PATH);
    this.conn.postTransaction(this.txSigned)
    .then(() => this.conn.pollStatusAndFetchTransaction(this.txSigned.id))
    .then(retrievedTx => console.log('Transaction', retrievedTx.id, 'successfully posted.'))
    
    // this.claimService.create(this.model)
    //   .subscribe(
    //     data => {
    //       this.alertService.success('Submit successful', true);
    //       this.router.navigate(['/home']);
    //       //this.loadAllClaims();
    //     },
    //     error => {
    //       this.alertService.error(error);
    //       //this.loading = false;
    //     });
  }

  // newClaim() {
  //   this.model = new Claim(42, '', '');
  // }
  deleteClaim(id: number) {
    this.claimService.delete(id).subscribe(() => { this.loadAllClaims() });
  }
  editClaim(id: number) {
    this.claimService.getById(id).subscribe(claim => { this.model = claim });;
    //console.log(this.model);
  }
  approveClaim(id: number) {
    alert("approved");
  }
  private loadAllClaims() {
    this.claimService.getAll().subscribe(claims => { this.claims = claims; });
  }
  isAuthor(user: string): boolean {
    //console.log(this.currentUser.username == user);
    return this.currentUser.username == user;
  }
  countryDropDownChanged(value: any){    
    if(value == "2"){      
      this.state_province = this.provinces;
    }
    else{
      this.state_province = this.states;
    }
  }
  test() {
    this.model = new Claim(1, "John", "John Business", "123 abc st.", "DC", "DC", 20001,
      "USA", "test@test.com", "123-123-1234", "http://test.com", "Baby", "DC", "9-5",
      "1001", "form1", this.currentUser.username);
  }
  ngOnInit() {
    this.loadAllClaims();
  }

}
