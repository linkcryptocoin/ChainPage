export class Claim {
    constructor(
        public id: number,
        public name: string,
        public businessName: string,
        public street: string,
        public city: string,
        public state: string,
        public zip: number,
        public country: string,
        public email: string,
        public phone: string,
        public webPage: string,
        public service: string,
        public servicingArea: string,
        public businessHour: string,
        public businessCategory: string,
        public formType: string,
        public submitBy: string
    ) {}
}