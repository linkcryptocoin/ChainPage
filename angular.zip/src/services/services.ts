import {MetaCoinService} from './meta-coin.service'
import {Web3Service} from './web3.service'


export {
    MetaCoinService,
    Web3Service,
};